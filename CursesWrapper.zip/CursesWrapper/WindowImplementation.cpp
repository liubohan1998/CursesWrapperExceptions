//
// Created by mfbut on 2/24/2019.
//

#include <iostream>
#include <string>

#include "WindowImplementation.h"

/*
 * I've already added the cut to initialize curses if it hasn't been called
 * and to create the window. You may still need to do more initialization if
 * you have other members
 */
Curses::WindowImplementation::WindowImplementation(int numRows, int numCols, int startRow, int startCol) :
    cursesWindow(nullptr, delwin) {
  if (!stdscr) {
    initscr();
  }
  cursesWindow = std::unique_ptr<WINDOW, decltype(delwin)*>(newwin(numRows, numCols, startRow, startCol), delwin);
}

Curses::WindowImplementation::WindowImplementation(int numRows, int numCols) : WindowImplementation(numRows, numCols, 0, 0) {

}

//the unique pointer will automatically delete itself
//but if you dynamically allocate any more space for this
//problem make sure to free it here.
Curses::WindowImplementation::~WindowImplementation() {

}

char Curses::WindowImplementation::getWindowChar(int row, int col) {
    return mvwinch(cursesWindow.get(), row, col);
}

char Curses::WindowImplementation::getWindowChar() {
    return winch(cursesWindow.get());
}

char Curses::WindowImplementation::getCharInput(int row, int col) {
    return mvwgetch(cursesWindow.get(), row, col);
}

char Curses::WindowImplementation::getCharInput() {
    return wgetch(cursesWindow.get());
}

std::string Curses::WindowImplementation::getStringInput(int row, int col) {
    char chara = '\0';
    std::string str;
    while(1){
        if (chara == '\n'){
            break;
        }
        else{
            chara = mvwgetch(cursesWindow.get(), row, col);
            str = str + chara;
            continue;
        }
    }
  return str;
}

std::string Curses::WindowImplementation::getStringInput() {
    char chara = '\0';
    std::string str;
    int row = getcury(cursesWindow.get());
    int col = getcurx(cursesWindow.get());
    while(1){
        if (chara == '\n'){
            break;
        }
        else{
            chara = mvwgetch(cursesWindow.get(), row, col);
            str = str + chara;
            continue;
        }
    }
    return str;
}

void Curses::WindowImplementation::addCharacter(int row, int col, char value){
    wmove(cursesWindow.get(), row, col);
    mvwaddch(cursesWindow.get(), row, col, value);
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());

    int max_col = getmaxx(cursesWindow.get());
    if(AdvanceCursor == false){
        if(ori_row != 0 && ori_col == 0){
            wmove(cursesWindow.get(), ori_row - 1, max_col - 1);
        }
        else{
            wmove(cursesWindow.get(), row, col);
        }
    }
}

void Curses::WindowImplementation::addCharacter(char value) {
    int row = getcury(cursesWindow.get());
    int col = getcurx(cursesWindow.get());
    waddch(cursesWindow.get(), value);
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());
    int max_col = getmaxx(cursesWindow.get());
    if(AdvanceCursor == false){
        if(ori_row != 0 && ori_col == 0){
            wmove(cursesWindow.get(), ori_row - 1, max_col - 1);
        }
        else{
            wmove(cursesWindow.get(), row, col);
        }
    }
}

void Curses::WindowImplementation::addString(int row, int col, const std::string& str) {
    wmove(cursesWindow.get(), row, col);
    mvwaddstr(cursesWindow.get(),row,col,str.c_str());
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());

    int max_col = getmaxx(cursesWindow.get());
    if(AdvanceCursor == false){
        if(ori_row != 0 && ori_col == 0){
            wmove(cursesWindow.get(), ori_row - 1, max_col - 1);
        }
        else{
            wmove(cursesWindow.get(), ori_row, ori_col - 1);
        }
    }
}

void Curses::WindowImplementation::addString(const std::string& str){
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());
    mvwaddstr(cursesWindow.get(),ori_row,ori_col,str.c_str());
    int new_row = getcury(cursesWindow.get());
    int new_col = getcurx(cursesWindow.get());

    int max_col = getmaxx(cursesWindow.get());
    if(AdvanceCursor == false){
        if(new_row != 0 && new_col == 0){
            wmove(cursesWindow.get(), new_row - 1, max_col - 1);
        }
        else{
            wmove(cursesWindow.get(), new_row, new_col - 1);
        }
    }
    
}

int Curses::WindowImplementation::getRowStart() const {
    return getbegy(cursesWindow.get());

}

int Curses::WindowImplementation::getColStart() const {
     return getbegx(cursesWindow.get());
}

int Curses::WindowImplementation::getNumRows() const {
    return getmaxy(cursesWindow.get());
}

int Curses::WindowImplementation::getNumCols() const {
    return getmaxx(cursesWindow.get());
}

int Curses::WindowImplementation::getCurRow() const {
    return getcury(cursesWindow.get());
}

int Curses::WindowImplementation::getCurCol() const {
    return getcurx(cursesWindow.get());
}

void Curses::WindowImplementation::moveCursor(int row, int col) {
    wmove(cursesWindow.get(), row, col);
}

void Curses::WindowImplementation::moveCursorLeft(int amount) {
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());

    
    // out of left boundary //
    if(ori_col - amount < 0){
        wmove(cursesWindow.get(), ori_row, 0);
    }
    // in left boundary //
    else{
        wmove(cursesWindow.get(), ori_row, ori_col - amount);
    }
}

void Curses::WindowImplementation::moveCursorRight(int amount) {
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());

    int max_col = getmaxx(cursesWindow.get());
    // out of right boundary //
    if(ori_col + amount > max_col - 1){
        wmove(cursesWindow.get(), ori_row, max_col - 1);
    }
    // in right boundary //
    else{
        wmove(cursesWindow.get(), ori_row, ori_col + amount);
    }

}

void Curses::WindowImplementation::moveCursorUp(int amount) {
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());


    // out of up boundary //
    if(ori_row - amount < 0){
        wmove(cursesWindow.get(), 0, ori_col);
    }
    // in up boundary //
    else{
        wmove(cursesWindow.get(), ori_row - amount, ori_col);
    }
    
}

void Curses::WindowImplementation::moveCursorDown(int amount) {
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());
    int max_row = getmaxy(cursesWindow.get());
    
    // out of down boundary //
    if(ori_row + amount > max_row - 1){
        wmove(cursesWindow.get(), max_row - 1, ori_col);
    }
    // in down boundary //
    else{
        wmove(cursesWindow.get(), ori_row + amount, ori_col);
    }

}

void Curses::WindowImplementation::setAdvanceCursorOn() {
    AdvanceCursor = true;
}

void Curses::WindowImplementation::setAdvanceCursorOff() {
    AdvanceCursor = false;
}

Curses::RowReference Curses::WindowImplementation::at(int row) {
  return RowReference(*this, row);
}

Curses::RowReference Curses::WindowImplementation::operator[](int row) {
  return RowReference(*this, row);
}

void Curses::WindowImplementation::refresh() {
    wrefresh(cursesWindow.get());
}

void Curses::WindowImplementation::log(std::ostream& out) {
    int ori_row = getcury(cursesWindow.get());
    int ori_col = getcurx(cursesWindow.get());
    int max_row = getmaxy(cursesWindow.get());
    int max_col = getmaxx(cursesWindow.get());
    for (int i = 0; i < max_row; ++i) {
        for (int j = 0; j < max_col; ++j) {
            out << ((cursesWindow.get())->getWindowChar(i,j));
        }
        out << std::endl;
    }
    moveCursor(ori_row, ori_col);
}
